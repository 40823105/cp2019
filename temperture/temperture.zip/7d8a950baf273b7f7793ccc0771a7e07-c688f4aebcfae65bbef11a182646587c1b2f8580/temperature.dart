int x = 0;
num F = 86;
num C = 30;

void main(){
  if (x == 0) {
  num F2 = C*9/5+32;
			print('F=$F2');
  }
  else{
    
    num C2 = (F-32)*5/9;
			print('C=$C2');
  }
  print('x=0,1切換(華氏、攝氏)');
  
}